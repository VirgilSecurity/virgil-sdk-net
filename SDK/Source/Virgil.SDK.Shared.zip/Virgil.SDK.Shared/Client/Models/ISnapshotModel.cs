﻿namespace Virgil.SDK.Client.Models
{
    public interface ISnapshotModel
    {
    }
}
