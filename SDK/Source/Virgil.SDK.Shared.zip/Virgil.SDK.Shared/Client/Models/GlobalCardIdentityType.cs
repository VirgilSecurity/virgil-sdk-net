﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Virgil.SDK.Client.Models
{
    public enum GlobalCardIdentityType
    {
        Email,
        Application
    }
}
